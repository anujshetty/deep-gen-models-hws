#!/usr/bin/env bash
zip -r cs236_hw1_2023.zip submit/ questions/
